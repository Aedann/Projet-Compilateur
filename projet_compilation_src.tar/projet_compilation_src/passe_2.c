
#include <stdio.h>

#include "defs.h"
#include "passe_2.h"

void gen_code_passe_2(node_t root) {

}
  
