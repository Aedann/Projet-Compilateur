
#include <stdio.h>

#include "defs.h"
#include "passe_1.h"

extern int trace_level;

void analyse_passe_1(node_t root) {

}
  
